### AnyKernel3 Ramdisk Debug Script
## osm0sis @ xda-developers

properties() { '
kernel.string=Custom Kernel Debug
do.devicecheck=0
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=
supported.versions=
supported.patchlevels=
'; }

block=/dev/block/platform/13520000.ufs/by-name/boot;
is_slot_device=auto;
ramdisk_compression=auto;
patch_vbmeta_flag=auto;

. tools/ak3-core.sh;

dump_boot;

PROP_FILE="system/etc/ramdisk/build.prop"

cur=$(file_getprop $PROP_FILE ro.bootimage.permissive)

if [ "$cur" = "1" ]; then
  new=0
else
  new=1
fi

patch_prop $PROP_FILE ro.bootimage.permissive $new

write_boot;